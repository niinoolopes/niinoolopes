// function initAccordion(){
//     const accordionList = document.querySelectorAll('.intro-list-accordion .accordion-header')
//     function activeIntroAcordion(){ 
//         this.querySelector('.icone').classList.toggle('ativo')
//         this.nextElementSibling.classList.toggle('ativo')
//     } 
//     accordionList.forEach( function(item){ 
//         item.addEventListener('click',activeIntroAcordion)
//     } );
// }
// initAccordion();