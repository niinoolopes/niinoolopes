/*
function initItemMenu() {
    const itemMenu = document.querySelectorAll('.menu a')
    const sectionBody = document.querySelectorAll('body > section');

    
    sectionBody.forEach((item)=>{ 
        if(!!item.getAttribute('id')){
            var id_item = item.getAttribute('id');
            var offsettop_item = item.offsetTop;

            console.log(window.pageYOffset , item.offsetTop)

        }
    })
 
 
}
initItemMenu();

window.addEventListener('scroll',initItemMenu)
*/